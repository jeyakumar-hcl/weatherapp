import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WeatherdetailsRoutingModule } from './weatherdetails-routing.module';
import { WeatherdetailsComponent } from './weatherdetails.component';


@NgModule({
  declarations: [WeatherdetailsComponent],
  imports: [
    CommonModule,
    WeatherdetailsRoutingModule
  ]
})
export class WeatherdetailsModule { }
