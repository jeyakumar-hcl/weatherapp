import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, NgZone } from '@angular/core';
import { HttpService } from '../../../shared/services/http.service';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators } from '@angular/forms';
declare var google;
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})

export class LandingComponent implements OnInit, AfterViewInit {
  weatherRecord: object[] = [];
  addCityForm: FormGroup;
  citiesList: object[] = [];
  googleCityList;
  constructor(private http: HttpService, private router: Router, private elRef: ElementRef, private zone: NgZone) { }


  ngOnInit() {
    this.citiesList = JSON.parse(sessionStorage.getItem('cityList')) || [];
    this.addCityForm = new FormGroup({
      city: new FormControl(null, [Validators.required])
    })
    this.getWeatherDetails();
  }

  //this method will call the weather api
  public getWeatherDetails() {
    this.weatherRecord = [];  
    this.citiesList.forEach((value) => {
      this.http.readData(value).subscribe(
        (res) => {
          this.weatherRecord.push(res);
        }
      )
    })
  }

  //this method will redirect to details page
  public detailedReport(cityname) {
    this.router.navigate(['weatherDetails'], { queryParams: { city: cityname } });
  }

  //this method will add city from search box
  public addCity() {
    if (this.citiesList.length > 3) {
      this.citiesList.shift();
    }    
    var ele = this.elRef.nativeElement.querySelector('#googleplaces').value;
    this.addCityForm.patchValue({city: ele})
    let isExist = this.citiesList.includes(this.addCityForm.value.city);
    if (!isExist) {
      this.citiesList.push(this.addCityForm.value.city);
      sessionStorage.setItem('cityList', JSON.stringify(this.citiesList));
      this.addCityForm.reset();
      this.getWeatherDetails();
    }
  }

//google mpas auto complete implement here
  ngAfterViewInit() {
    var ele = this.elRef.nativeElement.querySelector('#googleplaces');   
    if (google) {
      let options = {
        types: []
      };
      let googledata
      this.googleCityList = new google.maps.places.Autocomplete(ele, options);     
    }

  }

}
