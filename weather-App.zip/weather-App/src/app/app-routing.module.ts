import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WeatherdetailsModule } from './module/weatherdetails/weatherdetails.module';



export const routes: Routes = [ 
  {
    path: '',
    loadChildren: () => import('./module/home/home.module').then(home => home.HomeModule)   
  },
  {
    path: 'weatherDetails',
    loadChildren: () => import('./module/weatherdetails/weatherdetails.module').then(weather => weather.WeatherdetailsModule)   
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppModuleRoutingModule { }
