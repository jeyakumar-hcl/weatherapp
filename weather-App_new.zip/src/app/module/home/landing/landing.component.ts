import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, NgZone } from '@angular/core';
import { HttpService } from '../../../shared/services/http.service';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators } from '@angular/forms';
declare var google;
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})

export class LandingComponent implements OnInit {
  selectedWeather;
  addCityForm: FormGroup;
  weatherList: object[] = [];
  constructor(private http: HttpService, private router: Router, private elRef: ElementRef, private zone: NgZone) { }


  ngOnInit() {
    // this.citiesList = JSON.parse(sessionStorage.getItem('cityList')) || [];
    this.addCityForm = new FormGroup({
      city: new FormControl('', [Validators.required])
    })
    // this.getWeatherDetails();
  }

  public city() {
    this.getWeatherDetails(this.addCityForm.controls.city.value);
  }

  //this method will call the weather api
  public getWeatherDetails(city) {
    // this.weatherRecord = [];  
    // this.citiesList.forEach((value) => {
    this.http.readData(city).subscribe(
      (res: any) => {
        console.log(res.list);
        this.weatherList = [];

        for (let index = 0; index < 5; index++) {
          const currentday = new Date(new Date().setDate(new Date().getDate() + index));
          const day = {
            key: currentday,
            value: `Day${index + 1}`,
            weather: res.list.filter((item) => new Date(item.dt_txt).getDate() === currentday.getDate())
          }
          this.weatherList.push(day);          
        }
        this.selectedWeather=this.weatherList[0];
      }
    )
    // })
  }

  
  public getDayWeather(index){
   this.selectedWeather=this.weatherList[index];

  }
 



}
