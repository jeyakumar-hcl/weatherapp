import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  apiUrl = environment.apiUrl;
  apiId=environment.appId;
  userDetails = 'user';
  constructor(private http: HttpClient) {
  
  }
//get weather details
  readData(city) {
    const headers = new HttpHeaders();
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'GET');
    headers.append('Access-Control-Allow-Origin', '*');
    let apidetails=`${this.apiUrl+city+this.apiId}`;
    return this.http.get(apidetails);
  }
}
